package gewebe;

import processing.core.PVector;

public class Linef {
    public PVector p1 = new PVector();
    public PVector p2 = new PVector();
}
